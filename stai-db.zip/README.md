# Database STAI Morowali

Isi folder:

```
docker-compose.yml
.env.example          -> salin jadi .env
init/01-create-ojs.sh -> membuat DB + user terpisah untuk OJS
sql/schema.sql        -> 24 tabel, enum, index, trigger updated_at, view v_pmb_export
sql/seed.sql          -> admin, editor, 4 prodi, menu, periode PMB, contoh berita
sql/queries.sql       -> query contoh
erd.md                -> ERD Mermaid
```

## Menjalankan

```bash
cp .env.example .env        # lalu ganti semua password
mkdir -p backups
docker compose up -d
docker compose logs -f postgres     # pastikan tidak ada error
```

Skrip di `docker-entrypoint-initdb.d` **hanya jalan saat volume masih kosong**. Untuk mengulang dari nol (menghapus semua data):

```bash
docker compose down -v && docker compose up -d
```

pgAdmin (opsional): `docker compose --profile tools up -d`, buka http://localhost:5050.

## Cek hasil

```bash
docker exec -it staimorowali_postgres psql -U staimorowali -d staimorowali_web -c "\dt"
docker exec -it staimorowali_postgres psql -U staimorowali -d staimorowali_web -c "select code,name from study_programs;"
```

## Backup & restore

```bash
# backup
docker exec staimorowali_postgres pg_dump -U staimorowali -Fc staimorowali_web > backups/web_$(date +%F).dump
docker exec staimorowali_postgres pg_dump -U staimorowali -Fc ojs > backups/ojs_$(date +%F).dump

# restore
docker exec -i staimorowali_postgres pg_restore -U staimorowali -d staimorowali_web --clean --if-exists < backups/web_2026-10-09.dump
```

## Koneksi

- Website: `postgres://staimorowali:<password>@localhost:5432/staimorowali_web`
- OJS (saat instalasi): host `localhost` (atau `postgres` jika OJS satu jaringan Docker), database `ojs`, user `ojs_user`.

## Ekspor pendaftar ke Excel

```bash
docker exec staimorowali_postgres psql -U staimorowali -d staimorowali_web \
  -c "\copy (SELECT * FROM v_pmb_export) TO '/backups/pendaftar.csv' WITH CSV HEADER"
```
File CSV muncul di `backups/pendaftar.csv` dan bisa dibuka di Excel.

## PENTING: website Anda memakai Payload CMS

Payload membuat dan mengelola tabelnya sendiri (nama tabel dan kolomnya berbeda dari skema ini, misalnya tabel `_rels`, `_v`, `payload_migrations`). Ada dua jalur, pilih salah satu:

1. **Payload yang memegang skema (disarankan).** Jangan jalankan `schema.sql`/`seed.sql` di database yang dipakai Payload. Pakai skema ini sebagai acuan untuk menyusun *collection* Payload, lalu biarkan `payload migrate` membuat tabelnya. Untuk jalur ini, hapus dua baris `schema.sql` dan `seed.sql` dari `docker-compose.yml`.
2. **Skema ini yang dipakai langsung.** Kode website harus membaca tabel di sini lewat query/ORM sendiri, bukan lewat Payload.

Mencampur keduanya di satu database akan menimbulkan konflik.

## Sebelum produksi

- Ganti password admin/editor di `seed.sql` (hash bcrypt bawaan seed belum tentu cocok dengan format hash Payload).
- Ganti semua password di `.env`; port sudah dibatasi ke `127.0.0.1`.
- Isi data asli: sejarah, visi misi, dosen, koordinat peta.
