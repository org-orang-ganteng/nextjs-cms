# ERD Database `staimorowali_web`

```mermaid
erDiagram
  users ||--o{ media : uploaded_by
  users ||--o{ posts : author_id
  users ||--o{ announcements : author_id
  users ||--o{ audit_logs : user_id
  media ||--o{ site_settings : "logo/favicon"
  media ||--o{ home_settings : hero_image
  media ||--o{ posts : featured_image
  media ||--o{ gallery_items : media_id
  media ||--o{ pmb_applicant_documents : media_id

  navigation_items ||--o{ navigation_items : parent_id

  study_programs ||--o{ staff_members : study_program_id
  staff_members  ||--o| study_programs : head_staff_id
  staff_members  ||--o{ organization_structure : staff_id
  organization_structure ||--o{ organization_structure : parent_id

  post_categories ||--o{ posts : category_id

  gallery_albums ||--o{ gallery_items : album_id

  pages ||--o{ page_blocks : page_id

  pmb_periods ||--o{ pmb_applicants : period_id
  study_programs ||--o{ pmb_applicants : "first/second choice"
  pmb_applicants ||--o{ pmb_applicant_documents : applicant_id

  users {
    bigint id PK
    citext email UK
    user_role role
    boolean is_active
  }
  study_programs {
    bigint id PK
    varchar code UK
    varchar slug UK
    bigint head_staff_id FK
  }
  pmb_applicants {
    bigint id PK
    varchar registration_no UK
    bigint period_id FK
    char nik
    pmb_status status
    timestamptz deleted_at
  }
  posts {
    bigint id PK
    varchar slug UK
    content_status status
    timestamptz published_at
    timestamptz deleted_at
  }
```

Singleton (satu baris, `id = 1`): `site_settings`, `home_settings`, `campus_profile`.
