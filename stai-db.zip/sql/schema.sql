-- =====================================================================
-- Skema database: staimorowali_web  (PostgreSQL 16)
-- Website resmi STAI Morowali - RAB 004/RAB-IT/STAI-MRW/X/2026
-- Cakupan: website, CMS, PMB tahap awal. TIDAK termasuk: pembayaran,
-- CBT, SIAKAD/PDDIKTI, dan data jurnal (ditangani OJS di DB terpisah).
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------
-- Tipe ENUM
-- ---------------------------------------------------------------------
CREATE TYPE user_role       AS ENUM ('admin', 'editor');
CREATE TYPE content_status  AS ENUM ('draft', 'published', 'archived');
CREATE TYPE staff_type      AS ENUM ('dosen', 'tendik');
CREATE TYPE gallery_type    AS ENUM ('photo', 'video');
CREATE TYPE nav_location    AS ENUM ('header', 'footer');
CREATE TYPE gender_type     AS ENUM ('L', 'P');
CREATE TYPE pmb_status      AS ENUM ('baru', 'diproses', 'diverifikasi', 'ditolak');
CREATE TYPE message_status  AS ENUM ('unread', 'read', 'replied');

-- ---------------------------------------------------------------------
-- Fungsi trigger updated_at
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 1. USERS (login CMS, role Admin & Editor)
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name          varchar(150) NOT NULL,
  email         citext       NOT NULL UNIQUE,
  password_hash text         NOT NULL,
  role          user_role    NOT NULL DEFAULT 'editor',
  is_active     boolean      NOT NULL DEFAULT true,
  last_login_at timestamptz,
  created_at    timestamptz  NOT NULL DEFAULT now(),
  updated_at    timestamptz  NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 2. MEDIA (file upload)
-- ---------------------------------------------------------------------
CREATE TABLE media (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  filename    varchar(255) NOT NULL,
  url         text         NOT NULL,
  mime_type   varchar(100),
  filesize    bigint CHECK (filesize IS NULL OR filesize >= 0),
  width       integer,
  height      integer,
  alt_text    varchar(255),
  uploaded_by bigint REFERENCES users(id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_media_uploaded_by ON media(uploaded_by);

-- ---------------------------------------------------------------------
-- 3. SITE SETTINGS (singleton) + NAVIGATION
-- ---------------------------------------------------------------------
CREATE TABLE site_settings (
  id             smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  site_name      varchar(150) NOT NULL,
  tagline        varchar(255),
  logo_id        bigint REFERENCES media(id) ON DELETE SET NULL,
  favicon_id     bigint REFERENCES media(id) ON DELETE SET NULL,
  footer_text    text,
  social_links   jsonb NOT NULL DEFAULT '{}'::jsonb,  -- {"facebook":"...","instagram":"...","youtube":"...","tiktok":"..."}
  contact_email  citext,
  contact_phone  varchar(30),
  address        text,
  latitude       numeric(9,6) CHECK (latitude  BETWEEN -90  AND 90),
  longitude      numeric(9,6) CHECK (longitude BETWEEN -180 AND 180),
  maps_embed_url text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE navigation_items (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  location      nav_location NOT NULL DEFAULT 'header',
  group_label   varchar(100),            -- judul kolom tautan di footer
  parent_id     bigint REFERENCES navigation_items(id) ON DELETE CASCADE,
  label         varchar(100) NOT NULL,
  url           varchar(500) NOT NULL,
  open_new_tab  boolean NOT NULL DEFAULT false,
  sort_order    integer NOT NULL DEFAULT 0,
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  CHECK (parent_id IS NULL OR parent_id <> id)
);
CREATE INDEX idx_nav_location_order ON navigation_items(location, sort_order);
CREATE INDEX idx_nav_parent ON navigation_items(parent_id);

-- ---------------------------------------------------------------------
-- 4. HOME SETTINGS (singleton) + highlights + statistik
-- ---------------------------------------------------------------------
CREATE TABLE home_settings (
  id               smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  hero_title       varchar(255) NOT NULL,
  hero_subtitle    text,
  hero_image_id    bigint REFERENCES media(id) ON DELETE SET NULL,
  hero_cta_label   varchar(100),
  hero_cta_url     varchar(500),
  journal_title    varchar(150),
  journal_url      varchar(500),          -- tautan ke Rumah Jurnal (OJS)
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE home_highlights (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title       varchar(150) NOT NULL,
  description text,
  icon        varchar(60),
  image_id    bigint REFERENCES media(id) ON DELETE SET NULL,
  link_url    varchar(500),
  sort_order  integer NOT NULL DEFAULT 0,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE campus_stats (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  label       varchar(100) NOT NULL,
  value       varchar(50)  NOT NULL,     -- varchar agar bisa "500+" atau "A"
  icon        varchar(60),
  sort_order  integer NOT NULL DEFAULT 0,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 5. PROGRAM STUDI & STAFF (relasi melingkar -> FK kaprodi ditambah kemudian)
-- ---------------------------------------------------------------------
CREATE TABLE study_programs (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code             varchar(10)  NOT NULL UNIQUE,
  name             varchar(150) NOT NULL,
  slug             varchar(160) NOT NULL UNIQUE,
  degree_level     varchar(10)  NOT NULL DEFAULT 'S1',
  graduate_title   varchar(50),           -- contoh: S.Pd., S.H.
  description      text,
  vision           text,
  mission          text,
  graduate_profile text,
  career_prospects text,
  head_staff_id    bigint,                -- FK ditambah setelah staff_members ada
  accreditation    varchar(50),
  image_id         bigint REFERENCES media(id) ON DELETE SET NULL,
  sort_order       integer NOT NULL DEFAULT 0,
  is_published     boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE staff_members (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  full_name        varchar(150) NOT NULL,
  front_title      varchar(50),
  back_title       varchar(100),
  nidn             varchar(20) UNIQUE,
  staff_type       staff_type NOT NULL DEFAULT 'dosen',
  position         varchar(150),
  study_program_id bigint REFERENCES study_programs(id) ON DELETE SET NULL,
  email            citext,
  photo_id         bigint REFERENCES media(id) ON DELETE SET NULL,
  expertise        text,
  sort_order       integer NOT NULL DEFAULT 0,
  is_active        boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_staff_prodi ON staff_members(study_program_id);
CREATE INDEX idx_staff_type_active ON staff_members(staff_type, is_active);

ALTER TABLE study_programs
  ADD CONSTRAINT fk_prodi_head_staff
  FOREIGN KEY (head_staff_id) REFERENCES staff_members(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------
-- 6. PROFIL KAMPUS (singleton) + STRUKTUR ORGANISASI
-- ---------------------------------------------------------------------
CREATE TABLE campus_profile (
  id                 smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  history            text,
  vision             text,
  mission            text,
  welcome_title      varchar(150),
  welcome_text       text,
  welcome_name       varchar(150),        -- nama pejabat penyambut (Ketua)
  welcome_photo_id   bigint REFERENCES media(id) ON DELETE SET NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE organization_structure (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  position    varchar(150) NOT NULL,
  person_name varchar(150),
  staff_id    bigint REFERENCES staff_members(id) ON DELETE SET NULL,
  photo_id    bigint REFERENCES media(id) ON DELETE SET NULL,
  parent_id   bigint REFERENCES organization_structure(id) ON DELETE SET NULL,
  sort_order  integer NOT NULL DEFAULT 0,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  CHECK (parent_id IS NULL OR parent_id <> id)
);
CREATE INDEX idx_org_parent ON organization_structure(parent_id);

-- ---------------------------------------------------------------------
-- 7. BERITA, PENGUMUMAN, AGENDA
-- ---------------------------------------------------------------------
CREATE TABLE post_categories (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name       varchar(100) NOT NULL UNIQUE,
  slug       varchar(120) NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE posts (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title            varchar(255) NOT NULL,
  slug             varchar(280) NOT NULL UNIQUE,
  excerpt          text,
  content          jsonb,                 -- rich text (Lexical JSON) atau string HTML
  featured_image_id bigint REFERENCES media(id) ON DELETE SET NULL,
  category_id      bigint REFERENCES post_categories(id) ON DELETE SET NULL,
  author_id        bigint REFERENCES users(id) ON DELETE SET NULL,
  status           content_status NOT NULL DEFAULT 'draft',
  published_at     timestamptz,
  meta_title       varchar(255),
  meta_description varchar(320),
  deleted_at       timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (status <> 'published' OR published_at IS NOT NULL)
);
CREATE INDEX idx_posts_list ON posts(status, published_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX idx_posts_category ON posts(category_id);
CREATE INDEX idx_posts_author ON posts(author_id);

CREATE TABLE announcements (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title         varchar(255) NOT NULL,
  slug          varchar(280) NOT NULL UNIQUE,
  content       jsonb,
  attachment_id bigint REFERENCES media(id) ON DELETE SET NULL,
  published_at  timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz,
  is_pinned     boolean NOT NULL DEFAULT false,
  status        content_status NOT NULL DEFAULT 'draft',
  author_id     bigint REFERENCES users(id) ON DELETE SET NULL,
  deleted_at    timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  CHECK (expires_at IS NULL OR expires_at >= published_at)
);
CREATE INDEX idx_ann_list ON announcements(status, is_pinned DESC, published_at DESC) WHERE deleted_at IS NULL;

CREATE TABLE events (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title       varchar(255) NOT NULL,
  slug        varchar(280) NOT NULL UNIQUE,
  description jsonb,
  location    varchar(255),
  starts_at   timestamptz NOT NULL,
  ends_at     timestamptz,
  image_id    bigint REFERENCES media(id) ON DELETE SET NULL,
  status      content_status NOT NULL DEFAULT 'draft',
  deleted_at  timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  CHECK (ends_at IS NULL OR ends_at >= starts_at)
);
CREATE INDEX idx_events_list ON events(status, starts_at) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------
-- 8. GALERI
-- ---------------------------------------------------------------------
CREATE TABLE gallery_albums (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title        varchar(200) NOT NULL,
  slug         varchar(220) NOT NULL UNIQUE,
  description  text,
  cover_id     bigint REFERENCES media(id) ON DELETE SET NULL,
  event_date   date,
  sort_order   integer NOT NULL DEFAULT 0,
  is_published boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE gallery_items (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  album_id   bigint NOT NULL REFERENCES gallery_albums(id) ON DELETE CASCADE,
  item_type  gallery_type NOT NULL DEFAULT 'photo',
  media_id   bigint REFERENCES media(id) ON DELETE SET NULL,
  video_url  varchar(500),                -- URL YouTube untuk tipe video
  title      varchar(200),
  caption    text,
  taken_at   date,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (
    (item_type = 'photo' AND media_id IS NOT NULL) OR
    (item_type = 'video' AND (video_url IS NOT NULL OR media_id IS NOT NULL))
  )
);
CREATE INDEX idx_gallery_items_album ON gallery_items(album_id, sort_order);

-- ---------------------------------------------------------------------
-- 9. BLOCK PAGE BUILDER
-- ---------------------------------------------------------------------
CREATE TABLE pages (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title            varchar(255) NOT NULL,
  slug             varchar(280) NOT NULL UNIQUE,
  status           content_status NOT NULL DEFAULT 'draft',
  meta_title       varchar(255),
  meta_description varchar(320),
  og_image_id      bigint REFERENCES media(id) ON DELETE SET NULL,
  published_at     timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE page_blocks (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  page_id    bigint NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
  block_type varchar(40) NOT NULL
             CHECK (block_type IN ('hero','rich_text','image_text','cta','card_grid','gallery','faq','video','stats')),
  data       jsonb NOT NULL DEFAULT '{}'::jsonb,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_page_blocks_page ON page_blocks(page_id, sort_order);

-- ---------------------------------------------------------------------
-- 10. PMB TAHAP AWAL (tanpa pembayaran, CBT, SIAKAD)
-- ---------------------------------------------------------------------
CREATE TABLE pmb_periods (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  academic_year varchar(9)   NOT NULL CHECK (academic_year ~ '^[0-9]{4}/[0-9]{4}$'),
  name          varchar(100) NOT NULL,     -- "Gelombang 1"
  opens_at      date NOT NULL,
  closes_at     date NOT NULL,
  is_active     boolean NOT NULL DEFAULT false,
  fee_info      text,                      -- hanya teks informasi, bukan transaksi
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (academic_year, name),
  CHECK (closes_at >= opens_at)
);
CREATE INDEX idx_pmb_periods_active ON pmb_periods(is_active);

CREATE SEQUENCE pmb_registration_seq START 1;

CREATE TABLE pmb_applicants (
  id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  registration_no     varchar(30) NOT NULL UNIQUE
                      DEFAULT ('PMB-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('pmb_registration_seq')::text, 5, '0')),
  period_id           bigint NOT NULL REFERENCES pmb_periods(id) ON DELETE RESTRICT,
  full_name           varchar(150) NOT NULL,
  nik                 char(16) NOT NULL CHECK (nik ~ '^[0-9]{16}$'),
  gender              gender_type NOT NULL,
  birth_place         varchar(100) NOT NULL,
  birth_date          date NOT NULL CHECK (birth_date < CURRENT_DATE),
  address             text NOT NULL,
  phone               varchar(20) NOT NULL,
  email               citext,
  school_origin       varchar(200),
  graduation_year     smallint CHECK (graduation_year BETWEEN 1980 AND 2100),
  first_choice_id     bigint NOT NULL REFERENCES study_programs(id) ON DELETE RESTRICT,
  second_choice_id    bigint REFERENCES study_programs(id) ON DELETE RESTRICT,
  parent_name         varchar(150),
  parent_phone        varchar(20),
  info_source         varchar(100),
  status              pmb_status NOT NULL DEFAULT 'baru',
  admin_note          text,
  deleted_at          timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  CHECK (second_choice_id IS NULL OR second_choice_id <> first_choice_id)
);
-- Cegah pendaftar ganda (NIK sama pada periode yang sama)
CREATE UNIQUE INDEX uq_pmb_nik_period ON pmb_applicants(period_id, nik) WHERE deleted_at IS NULL;
CREATE INDEX idx_pmb_status ON pmb_applicants(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_pmb_first_choice ON pmb_applicants(first_choice_id);
CREATE INDEX idx_pmb_created ON pmb_applicants(created_at DESC);

CREATE TABLE pmb_applicant_documents (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  applicant_id bigint NOT NULL REFERENCES pmb_applicants(id) ON DELETE CASCADE,
  doc_type     varchar(50) NOT NULL,       -- ijazah, kk, foto, dll.
  media_id     bigint NOT NULL REFERENCES media(id) ON DELETE RESTRICT,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (applicant_id, doc_type)
);

-- ---------------------------------------------------------------------
-- 11. INBOX PESAN KONTAK
-- ---------------------------------------------------------------------
CREATE TABLE contact_messages (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name       varchar(150) NOT NULL,
  email      citext NOT NULL,
  phone      varchar(30),
  subject    varchar(200),
  message    text NOT NULL,
  status     message_status NOT NULL DEFAULT 'unread',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_contact_status ON contact_messages(status, created_at DESC);

-- ---------------------------------------------------------------------
-- 12. AUDIT LOG
-- ---------------------------------------------------------------------
CREATE TABLE audit_logs (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id     bigint REFERENCES users(id) ON DELETE SET NULL,
  action      varchar(20) NOT NULL CHECK (action IN ('create','update','delete','login','export')),
  table_name  varchar(80) NOT NULL,
  record_id   bigint,
  changes     jsonb,
  ip_address  inet,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_user ON audit_logs(user_id, created_at DESC);
CREATE INDEX idx_audit_table ON audit_logs(table_name, record_id);

-- ---------------------------------------------------------------------
-- VIEW: siap ekspor Excel data pendaftar
-- ---------------------------------------------------------------------
CREATE VIEW v_pmb_export AS
SELECT
  a.registration_no                AS "No Pendaftaran",
  per.academic_year                AS "Tahun Akademik",
  per.name                         AS "Gelombang",
  a.full_name                      AS "Nama Lengkap",
  a.nik                            AS "NIK",
  CASE a.gender WHEN 'L' THEN 'Laki-laki' ELSE 'Perempuan' END AS "Jenis Kelamin",
  a.birth_place || ', ' || to_char(a.birth_date, 'DD-MM-YYYY') AS "Tempat, Tgl Lahir",
  a.address                        AS "Alamat",
  a.phone                          AS "No HP/WA",
  a.email                          AS "Email",
  a.school_origin                  AS "Asal Sekolah",
  a.graduation_year                AS "Tahun Lulus",
  p1.name                          AS "Prodi Pilihan 1",
  p2.name                          AS "Prodi Pilihan 2",
  a.parent_name                    AS "Orang Tua/Wali",
  a.parent_phone                   AS "HP Orang Tua",
  a.info_source                    AS "Sumber Informasi",
  a.status::text                   AS "Status",
  a.admin_note                     AS "Catatan Admin",
  to_char(a.created_at AT TIME ZONE 'Asia/Makassar', 'DD-MM-YYYY HH24:MI') AS "Tanggal Daftar"
FROM pmb_applicants a
JOIN pmb_periods per   ON per.id = a.period_id
JOIN study_programs p1 ON p1.id = a.first_choice_id
LEFT JOIN study_programs p2 ON p2.id = a.second_choice_id
WHERE a.deleted_at IS NULL
ORDER BY a.created_at;

-- ---------------------------------------------------------------------
-- Pasang trigger updated_at ke semua tabel yang punya kolom tersebut
-- ---------------------------------------------------------------------
DO $$
DECLARE t text;
BEGIN
  FOR t IN
    SELECT c.table_name
    FROM information_schema.columns c
    JOIN information_schema.tables tb
      ON tb.table_name = c.table_name AND tb.table_schema = c.table_schema
    WHERE c.table_schema = 'public'
      AND c.column_name = 'updated_at'
      AND tb.table_type = 'BASE TABLE'
  LOOP
    EXECUTE format(
      'CREATE TRIGGER trg_%I_updated_at BEFORE UPDATE ON %I
       FOR EACH ROW EXECUTE FUNCTION set_updated_at()', t, t);
  END LOOP;
END $$;
