-- (a) 10 berita terbaru yang sudah terbit
SELECT p.id, p.title, p.slug, p.excerpt, p.published_at, c.name AS kategori
FROM posts p
LEFT JOIN post_categories c ON c.id = p.category_id
WHERE p.status = 'published' AND p.deleted_at IS NULL AND p.published_at <= now()
ORDER BY p.published_at DESC
LIMIT 10;

-- (b) Pengumuman aktif (belum kedaluwarsa), yang disematkan di atas
SELECT id, title, slug, published_at, expires_at, is_pinned
FROM announcements
WHERE status = 'published' AND deleted_at IS NULL
  AND published_at <= now()
  AND (expires_at IS NULL OR expires_at > now())
ORDER BY is_pinned DESC, published_at DESC;

-- (c) Jumlah pendaftar per prodi (pilihan 1) dan status
SELECT sp.code AS prodi, a.status, count(*) AS jumlah
FROM pmb_applicants a
JOIN study_programs sp ON sp.id = a.first_choice_id
WHERE a.deleted_at IS NULL
GROUP BY sp.code, a.status
ORDER BY sp.code, a.status;

-- (d) Siap ekspor Excel / CSV (jalankan dari psql)
--   \copy (SELECT * FROM v_pmb_export) TO 'pendaftar.csv' WITH CSV HEADER
SELECT * FROM v_pmb_export;

-- (e) Pesan kontak yang belum dibaca
SELECT id, name, email, subject, created_at
FROM contact_messages WHERE status = 'unread' ORDER BY created_at DESC;

-- (f) Menu navigasi header (hierarkis)
SELECT id, parent_id, label, url, sort_order
FROM navigation_items
WHERE location = 'header' AND is_active
ORDER BY sort_order;
