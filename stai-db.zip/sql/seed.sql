-- =====================================================================
-- Seed data awal - GANTI password & data placeholder sebelum produksi
-- =====================================================================

-- Users (password awal: GantiPassword123! -> WAJIB diganti)
INSERT INTO users (name, email, password_hash, role) VALUES
 ('Administrator',  'admin@staimorowali.ac.id',  crypt('GantiPassword123!', gen_salt('bf', 12)), 'admin'),
 ('Editor Konten',  'editor@staimorowali.ac.id', crypt('GantiPassword123!', gen_salt('bf', 12)), 'editor');

-- Pengaturan situs
INSERT INTO site_settings (site_name, tagline, footer_text, social_links, address)
VALUES (
  'STAI Morowali',
  'Sekolah Tinggi Agama Islam Morowali',
  '© 2026 STAI Morowali. Hak cipta dilindungi.',
  '{"facebook":"","instagram":"","youtube":"","tiktok":""}'::jsonb,
  'Jalan Sultan Hasanuddin, Kelurahan Matano, Kecamatan Bungku Tengah, Kabupaten Morowali, Sulawesi Tengah'
);

INSERT INTO home_settings (hero_title, hero_subtitle, hero_cta_label, hero_cta_url, journal_title, journal_url)
VALUES (
  'Selamat Datang di STAI Morowali',
  'Mencetak generasi berilmu, berakhlak, dan berkarakter Islami.',
  'Daftar Sekarang', '/pmb',
  'Rumah Jurnal STAI Morowali', 'https://jurnal.staimorowali.ac.id'
);

INSERT INTO campus_profile (history, vision, mission, welcome_title, welcome_name)
VALUES (NULL, NULL, NULL, 'Sambutan Ketua', 'Dr. H. Najamudin, S.Ag., S.Pd., M.Pd.');

INSERT INTO campus_stats (label, value, icon, sort_order) VALUES
 ('Program Studi', '4', 'book-open', 1),
 ('Dosen', '0', 'users', 2),
 ('Mahasiswa', '0', 'graduation-cap', 3);

INSERT INTO organization_structure (position, person_name, sort_order)
VALUES ('Ketua STAI Morowali', 'Dr. H. Najamudin, S.Ag., S.Pd., M.Pd.', 1);

-- 4 Program Studi
INSERT INTO study_programs (code, name, slug, degree_level, graduate_title, sort_order) VALUES
 ('PAI',   'Pendidikan Agama Islam',                  'pendidikan-agama-islam',                  'S1', 'S.Pd.', 1),
 ('PGMI',  'Pendidikan Guru Madrasah Ibtidaiyah',     'pendidikan-guru-madrasah-ibtidaiyah',     'S1', 'S.Pd.', 2),
 ('PIAUD', 'Pendidikan Islam Anak Usia Dini',         'pendidikan-islam-anak-usia-dini',         'S1', 'S.Pd.', 3),
 ('HKI',   'Hukum Keluarga Islam',                    'hukum-keluarga-islam',                    'S1', 'S.H.',  4);

-- Navigasi header
INSERT INTO navigation_items (location, label, url, sort_order) VALUES
 ('header', 'Beranda',        '/',            1),
 ('header', 'Profil',         '/profil',      2),
 ('header', 'Program Studi',  '/program-studi', 3),
 ('header', 'Dosen & Staf',   '/dosen',       4),
 ('header', 'Berita',         '/berita',      5),
 ('header', 'Pengumuman',     '/pengumuman',  6),
 ('header', 'Agenda',         '/agenda',      7),
 ('header', 'Galeri',         '/galeri',      8),
 ('header', 'PMB',            '/pmb',         9),
 ('header', 'Rumah Jurnal',   'https://jurnal.staimorowali.ac.id', 10),
 ('header', 'Kontak',         '/kontak',      11);

UPDATE navigation_items SET open_new_tab = true WHERE label = 'Rumah Jurnal';

-- Periode PMB contoh
INSERT INTO pmb_periods (academic_year, name, opens_at, closes_at, is_active, fee_info)
VALUES ('2026/2027', 'Gelombang 1', '2026-10-15', '2026-12-31', true,
        'Informasi biaya akan diumumkan oleh panitia PMB.');

-- Kategori & berita contoh
INSERT INTO post_categories (name, slug) VALUES ('Berita Kampus', 'berita-kampus');

INSERT INTO posts (title, slug, excerpt, content, category_id, author_id, status, published_at)
SELECT 'Website Resmi STAI Morowali Diluncurkan', 'website-resmi-stai-morowali-diluncurkan',
       'STAI Morowali meluncurkan website resmi sebagai sarana informasi akademik.',
       to_jsonb('Konten berita contoh. Silakan ganti melalui panel admin.'::text),
       (SELECT id FROM post_categories WHERE slug = 'berita-kampus'),
       (SELECT id FROM users WHERE email = 'admin@staimorowali.ac.id'),
       'published', now();

INSERT INTO posts (title, slug, excerpt, content, category_id, author_id, status, published_at)
SELECT 'Pembukaan Penerimaan Mahasiswa Baru 2026/2027', 'pembukaan-pmb-2026-2027',
       'Pendaftaran mahasiswa baru STAI Morowali telah dibuka untuk 4 program studi.',
       to_jsonb('Konten berita contoh. Silakan ganti melalui panel admin.'::text),
       (SELECT id FROM post_categories WHERE slug = 'berita-kampus'),
       (SELECT id FROM users WHERE email = 'editor@staimorowali.ac.id'),
       'published', now() - interval '1 day';

-- Pengumuman contoh
INSERT INTO announcements (title, slug, content, published_at, expires_at, is_pinned, status, author_id)
SELECT 'Pengumuman Pendaftaran Mahasiswa Baru', 'pengumuman-pendaftaran-mahasiswa-baru',
       to_jsonb('Pendaftaran gelombang 1 dibuka. Informasi lengkap tersedia di halaman PMB.'::text),
       now(), now() + interval '90 days', true, 'published',
       (SELECT id FROM users WHERE email = 'admin@staimorowali.ac.id');
